package com.utils;

import android.content.Intent;

import java.util.ArrayList;
import java.util.List;

public class Constant
{
 public class HeaderParams {
  public static final String ACCEPT_TYPE = "application/json";
  public static final String CONTENT_TYPE = "application/x-www-form-urlencoded";
 }
 public class Messages {
  public static final String SERVER_RESPONCE = "Received data is not compatible.";
 }
}
