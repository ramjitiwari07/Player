package com.Manager;

/**
 * Created by Praveen on 11-Jul-17.
 */

public interface CallBackManager {

    void onSuccess(String responce);
    void onFailure(String responce);
}
